package com.springboot.dbauthentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbauthenticationApplicationTests {

	@Test
	void contextLoads() {
	}

}
